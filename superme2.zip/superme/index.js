const express = require("express");
const app = express();
const port = 35000;
const bodyParser = require("body-parser");
const lineNotify = require("line-notify-nodejs")(
  "IK13jWmplLsqslYwBLaoQJuPdz4fvBcb9Ph5tKPbKFh"
);
const nodemailer = require("nodemailer");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use("/", express.static(__dirname + "/view"));
app.use("/thank", express.static(__dirname + "/view/thankyou.html"));

app.post("/sending", (req, res) => {
  var name = req.body.name;
  var phone = req.body.phone;
  var address = req.body.address;
  console.log(req.body);

  lineNotify
    .notify({
      message: `-- สั่ง superme fharmatech -- \n ชื่อ-นามสกุล :  ${name} \n เบอร์โทร :  ${phone} \n ที่อยู่ :  ${address}   \n`,
    })
    .then(() => {
      console.log("send completed!");
      const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: "pimpatbutsuwan1991@gmail.com",
          pass: "pimpat1991",
        },
      });

      let mailOptions = {
        from: "pimpatbutsuwan1991@gmail.com",
        to: "pimpatbutsuwan1991@gmail.com",
        subject: "Superme Pharmatech",
        text: `-- สั่ง superme fharmatech -- \n ชื่อ-นามสกุล :  ${name} \n เบอร์โทร :  ${phone} \n ที่อยู่ :  ${address}   \n`,
      };

      transporter.sendMail(mailOptions, function (error, info) {
        if (error) console.log(error);
        else console.log("Email sent: " + info.response);
      });

      return res.redirect("/thank");
    });
});

app.listen(port, () => {
  console.log(`Server is running at ${port}`);
});
